# Data Analysis: IT Project Management, Project 1

## 1. Course
IT Project Management

## 2. Team: Mamur_Team

| Name | Student ID | Group | Role |
|------|-----------|-------|------|
| Tuychiboyev Elbek | 202490341 | I24B | Leader |
| Muxammetkulov Abduraxmon | 202490209 | I24B | Coder |
| Mustafoyev Ulug'bek | 202490206 | I24B | Designer |

## 3. Project Title
Data Analysis: *(add the topic once your dataset is chosen, e.g. "Data Analysis of ...")*

## 4. Dataset Information
- **Dataset title:** TODO
- **Source website / URL:** TODO
- **Description:** TODO
- **Why we selected it:** TODO
- **Size (rows, columns):** TODO (run `df.shape`)

## 5. Project Objectives
- **Problem to solve:** TODO
- **Questions to answer:**
  1. TODO
  2. TODO
  3. TODO
- **Expected insights:** TODO

## 6. Data Preparation (Pandas)
Full code is in [`analysis.py`](analysis.py).

```python
import pandas as pd

df = pd.read_csv("data/dataset.csv")      # load
print(df.shape, df.dtypes)

df = df.drop_duplicates()                  # duplicates
print(df.isna().sum())                     # missing values
df = df.dropna(subset=["important_column"])
df["date"] = pd.to_datetime(df["date"])    # data types
df["year"] = df["date"].dt.year            # new feature
```

Explanation: TODO (what was missing, what you removed or filled, and why).

## 7. Data Analysis Tasks (Pandas)
```python
filtered = df[df["year"] >= 2020]                         # filtering
top10 = df.sort_values("value", ascending=False).head(10) # sorting
by_group = df.groupby("category")["value"].agg(["mean", "sum", "count"])
pivot = df.pivot_table(index="category", columns="year",
                       values="value", aggfunc="mean")
```

Answers to the objective questions: TODO (include code, output, and a short explanation for each).

## 8. Key Findings and Insights
- Finding 1: TODO
- Finding 2: TODO
- Real-world interpretation: TODO

## 9. Project Timeline

| Week | Activities | Status |
|------|-----------|--------|
| Week 1 (07 Sep - 13 Sep) | Dataset search and project planning | Done |
| Week 2 (14 Sep - 20 Sep) | Data cleaning and preparation | |
| Week 3 (21 Sep - 27 Sep) | Data analysis and visualization | |
| Week 4-5 (28 Sep - 13 Oct) | Report writing and presentation preparation | |

**Presentation:** 14 Oct

## 10. Outcome of the Project
- What we learned: TODO
- Pandas skills developed: loading, cleaning, grouping, pivot tables, visualization

## 11. Conclusion
TODO: summarize the project and why it matters.

## 12. References
- Dataset source: TODO
- [Pandas documentation](https://pandas.pydata.org/docs/)

## 13. Appendix
Extra charts are saved in [`charts/`](charts/). Add important code snippets and tables here.
