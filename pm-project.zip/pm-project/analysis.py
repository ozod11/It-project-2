"""Mamur_Team: IT Project Management, Project 1.
Put your CSV in data/ and edit the column names below."""
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("data/dataset.csv")
print(df.shape)
print(df.info())

# Cleaning
df = df.drop_duplicates()
print(df.isna().sum())

# Analysis (edit column names)
# summary = df.groupby("category")["value"].mean().sort_values(ascending=False)
# print(summary)
# summary.plot(kind="bar", title="Average value by category")
# plt.tight_layout()
# plt.savefig("charts/average_by_category.png")
